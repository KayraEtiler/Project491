import { MigrationInterface, QueryRunner } from "typeorm";

export class CreateMovieTable1705537368573 implements MigrationInterface {
    name = 'CreateMovieTable1705537368573'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`CREATE TABLE "movie" ("id" integer NOT NULL, "title" character varying NOT NULL, "genres" character varying NOT NULL, CONSTRAINT "PK_cb3bb4d61cf764dc035cbedd422" PRIMARY KEY ("id"))`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`DROP TABLE "movie"`);
    }

}
