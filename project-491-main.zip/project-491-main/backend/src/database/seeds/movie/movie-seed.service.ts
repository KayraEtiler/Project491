import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Movie } from 'src/movies/entities/movie.entity';
import { Repository } from 'typeorm';

@Injectable()
export class MovieSeedService {
  constructor(
    @InjectRepository(Movie)
    private repository: Repository<Movie>,
  ) {}

  async run() {
    const count = await this.repository.count();

    if (count === 0) {
      const movies = [
        {
          movie_id: '19995',
          title: 'Avatar',
          cast: JSON.parse('[{"cast_id": 242, "character": "Jake Sully", "credit_id": "5602a8a7c3a3685532001c9a", "gender": 2, "id": 65731, "name": "Sam Worthington", "order": 0}, {"cast_id": 3, "character": "Neytiri", "credit_id": "52fe48009251416c750ac9cb", "gender": 1, "id": 8691, "name": "Zoe Saldana", "order": 1}]'), // Diğer cast üyeleri ile tam bir JSON array'i sağlayın
          crew: JSON.parse('[{"credit_id": "52fe48009251416c750aca23", "department": "Editing", "gender": 0, "id": 1721, "job": "Editor", "name": "Stephen E. Rivkin"}]'), // Diğer crew üyeleri ile tam bir JSON array'i sağlayın
        },
        // Daha fazla film...
      ];
      // Film verilerini veritabanına kaydedin
      await this.repository.save(movies.map(movie => this.repository.create(movie)));
    }
  }
}
