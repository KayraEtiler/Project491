import { Entity, PrimaryColumn, Column } from 'typeorm';
import { EntityHelper } from 'src/utils/entity-helper';
import { ApiProperty } from '@nestjs/swagger';

@Entity()
export class Movie extends EntityHelper {
  @PrimaryColumn({ type: 'int' })
  id: number;  // Film için benzersiz tanımlayıcı

  @ApiProperty({ example: 'Toy Story' })
  @Column()
  title: string;

  @ApiProperty({ example: 'Adventure|Animation|Children|Comedy|Fantasy' })
  @Column()
  genres: string;
}