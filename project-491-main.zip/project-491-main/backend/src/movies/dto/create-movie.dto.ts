import { IsNotEmpty, IsString, IsArray, ValidateNested, IsNumber } from 'class-validator';
import { Type } from 'class-transformer';
import { ApiProperty } from '@nestjs/swagger';

class CastMemberDto {
  @ApiProperty({ example: 242 })
  @IsNumber()
  cast_id: number;

  @ApiProperty({ example: 'Andy Dufresne' })
  @IsString()
  character: string;

  @ApiProperty({ example: 'Tim Robbins' })
  @IsString()
  name: string;
}

class CrewMemberDto {
  @ApiProperty({ example: '52fe48009251416c750aca23' })
  @IsString()
  credit_id: string;

  @ApiProperty({ example: 'Editing' })
  @IsString()
  department: string;

  @ApiProperty({ example: 'Stephen E. Rivkin' })
  @IsString()
  name: string;
}

export class CreateMovieDto {
  @ApiProperty({ example: 'tt0111161' })
  @IsString()
  @IsNotEmpty()
  movie_id: string;

  @ApiProperty({ example: 'The Shawshank Redemption' })
  @IsString()
  @IsNotEmpty()
  title: string;

  @ApiProperty({ type: [CastMemberDto] })
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => CastMemberDto)
  cast: CastMemberDto[];

  @ApiProperty({ type: [CrewMemberDto] })
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => CrewMemberDto)
  crew: CrewMemberDto[];
}
