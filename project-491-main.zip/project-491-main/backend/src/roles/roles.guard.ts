import { Injectable, CanActivate, ExecutionContext } from '@nestjs/common';
import { Reflector } from '@nestjs/core';

@Injectable()
export class RolesGuard implements CanActivate {
  constructor(private reflector: Reflector) {}

  canActivate(context: ExecutionContext): boolean {
    const requiredRoles = this.reflector.getAllAndOverride<number[]>('roles', [
      context.getClass(),
      context.getHandler(),
    ]);
    console.log('Gerekli Roller:', requiredRoles);
  
    const request = context.switchToHttp().getRequest();
    console.log('Kullanıcı Rolü:', request.user?.role?.id);
  
    if (!requiredRoles || requiredRoles.length === 0) {
      return false;
    }
  
    if (!request.user || !request.user.role) {
      return false;
    }
  
    const accessGranted = requiredRoles.includes(request.user.role.id);
    console.log('Erişim Verildi:', accessGranted);
    return accessGranted;
  }
  
}
