import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Rating } from './entities/rating.entity';
import { Repository, DeepPartial, FindOptionsWhere } from 'typeorm';
import { EntityCondition } from 'src/utils/types/entity-condition.type';
import { IPaginationOptions } from 'src/utils/types/pagination-options';
import { NullableType } from '../utils/types/nullable.type';

@Injectable()
export class RatingService {
  constructor(
    @InjectRepository(Rating)
    private ratingRepository: Repository<Rating>,
  ) {}

  createRating(ratingData: DeepPartial<Rating>): Promise<Rating> {
    return this.ratingRepository.save(this.ratingRepository.create(ratingData));
  }

  updateRating(id: number, updateData: DeepPartial<Rating>): Promise<Rating> {
    return this.ratingRepository.save({ ...updateData, id });
  }

  findRatingByUserId(userId: number): Promise<Rating[]> {
    return this.ratingRepository.find({ where: { userId } });
  }

  findAllRatings({
    filterOptions,
    paginationOptions,
  }: {
    filterOptions?: FindOptionsWhere<Rating> | null;
    paginationOptions?: IPaginationOptions;
  }): Promise<Rating[]> {
    const whereCondition = filterOptions || {};
    const skip = paginationOptions?.page ? (paginationOptions.page - 1) * paginationOptions.limit : undefined;
    const take = paginationOptions?.limit;
  
    return this.ratingRepository.find({
      where: whereCondition,
      skip,
      take,
    });
  }  

  deleteRating(id: number): Promise<void> {
    return this.ratingRepository.softDelete(id).then(() => {});
  }
}
