import {
  Controller,
  Get,
  Post,
  Body,
  Patch,
  Param,
  Delete,
  UseGuards,
  HttpStatus,
  HttpCode,
  Req,
} from '@nestjs/common';
import { RatingService } from './rating.service';
import { CreateRatingDto } from './dto/create-rating.dto';
import { UpdateRatingDto } from './dto/update-rating.dto';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { AuthGuard } from '@nestjs/passport';
import { RolesGuard } from 'src/roles/roles.guard';
import { Roles } from 'src/roles/roles.decorator';
import { RoleEnum } from 'src/roles/roles.enum';
import { Rating } from './entities/rating.entity';
import { Request } from 'express';
import { User } from '../users/entities/user.entity';

@ApiBearerAuth()
@UseGuards(AuthGuard('jwt'), RolesGuard)
@ApiTags('Ratings')
@Controller({
  path: 'ratings',
  version: '1',
})
export class RatingController {
  constructor(private readonly ratingService: RatingService) {}

  @Post()
  @Roles(RoleEnum.admin)
  @HttpCode(HttpStatus.CREATED)
  create(@Body() createRatingDto: CreateRatingDto, @Req() req: Request): Promise<Rating> {
    const user = req.user as User; // User türüne dönüştürme
    if (!user || !user.id) {
      throw new Error('User ID is not available');
    }
    return this.ratingService.createRating({ ...createRatingDto, userId: user.id });
  }

  @Get(':userId')
  @Roles(RoleEnum.admin)
  @HttpCode(HttpStatus.OK)
  findRatingsByUserId(@Param('userId') userId: number): Promise<Rating[]> {
    return this.ratingService.findRatingByUserId(userId);
  }
  @Patch(':userId')
  @HttpCode(HttpStatus.OK)
  update(@Param('movieId') id: number, @Body() updateRatingDto: UpdateRatingDto): Promise<Rating> {
    // Bu fonksiyonun nasıl çalıştığına dair detaylar 'RatingService' içinde belirlenmeli.
    return this.ratingService.updateRating(id, updateRatingDto);
  }


  @Delete(':movieId')
  @Roles(RoleEnum.admin)
  @HttpCode(HttpStatus.NO_CONTENT)
  remove(@Param('id') id: number): Promise<void> {
    return this.ratingService.deleteRating(id);
  }
}