import { IsNotEmpty, IsNumber, IsOptional } from 'class-validator';

export class CreateRatingDto {
  @IsNumber()
  @IsNotEmpty()
  userId: number;

  @IsNumber()
  @IsOptional()
  movieId: number;

  @IsNumber()
  @IsOptional()
  rating: number;

  @IsNumber()
  @IsOptional()
  timestamp: number;
}
