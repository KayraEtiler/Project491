import { Injectable } from '@nestjs/common';
import { AxiosHttpService  } from '../http-client/http.service';

@Injectable()
export class RecommendationService {
  constructor(private httpService: AxiosHttpService) {}

  async getRecommendations(userId: string): Promise<any> {
    try {
      const response = await this.httpService.get(`[Python Mikroservisinizin URL'si]/recommendations/${userId}`);
      return response.data;
    } catch (error) {
      // Hata yönetimi
      throw new Error('Python mikroservisiyle iletişimde hata oluştu.');
    }
  }
}