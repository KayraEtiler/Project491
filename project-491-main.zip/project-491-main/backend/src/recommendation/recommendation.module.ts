import { Module } from '@nestjs/common';
import { RecommendationService } from './recommendation.service';
import { RecommendationController } from './recommendation.controller';
import { AxiosHttpService } from '../http-client/http.service';

@Module({
  controllers: [RecommendationController],
  providers: [RecommendationService, AxiosHttpService],
})
export class RecommendationModule {}
