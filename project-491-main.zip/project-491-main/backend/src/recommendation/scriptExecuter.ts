import { Injectable } from '@nestjs/common';
import { exec } from 'child_process';
import { promisify } from 'util';
const execAsync = promisify(exec);

@Injectable()
export class RecommendationService {
  async getRecommendations(userId: string): Promise<any> {
    try {
      const scriptPath = 'src/recommendation/scripts/recommendation_script.py';
      const { stdout, stderr } = await execAsync(`python ${scriptPath} ${userId}`);

      if (stderr) {
        throw new Error(`Script Error: ${stderr}`);
      }

      return JSON.parse(stdout);
    } catch (error) {
      throw new Error(`Execution Error: ${error.message}`);
    }
  }
}