import { ApiProperty } from '@nestjs/swagger';

export class CreateMovieRecommendationDto {
  @ApiProperty({ example: ['action', 'comedy'], description: 'List of preferred genres' })
  readonly genres: string[];

  @ApiProperty({ example: 2020, description: 'Year of release' })
  readonly year: number;

  // Diğer gerekli alanlar...
}