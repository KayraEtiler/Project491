import pandas as pd
import os

# CSV dosyalarını oku
movie_df = pd.read_csv('D:/sLeDa/movies.csv')
rating_df = pd.read_csv('D:/sLeDa/ratings.csv')

# movie veri setindeki movieId'lerin bir listesini oluştur
movie_ids = set(movie_df['movieId'])

# rating veri setinde, movie veri setinde olmayan movieId'leri bul
non_matching_ratings = rating_df[~rating_df['movieId'].isin(movie_ids)]

# Mevcut çalışma dizinini al ve yazdır
current_directory = os.getcwd()
print("Mevcut çalışma dizini:", current_directory)

# Eşleşmeyen satırları konsola yazdır
print("Eşleşmeyen satırlar:")
print(non_matching_ratings)

# rating veri setinde, movie veri setinde olan movieId'leri filtrele
filtered_rating_df = rating_df[rating_df['movieId'].isin(movie_ids)]

# Filtrelenmiş veriyi yeni bir CSV dosyasına kaydet
filtered_rating_df.to_csv('filtered_rating.csv', index=False)