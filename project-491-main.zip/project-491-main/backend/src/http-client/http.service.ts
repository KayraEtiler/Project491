import { Injectable } from '@nestjs/common';
import axios, { AxiosRequestConfig } from 'axios';

@Injectable()
export class AxiosHttpService {
  async get(url: string, config?: AxiosRequestConfig) {
    return axios.get(url, config);
  }

  async post(url: string, data?: any, config?: AxiosRequestConfig) {
    return axios.post(url, data, config);
  }

  // İhtiyaç duyulan diğer HTTP metodları için benzer fonksiyonlar eklenebilir
}
