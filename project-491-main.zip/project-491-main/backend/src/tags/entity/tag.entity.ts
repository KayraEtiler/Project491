import { Entity, PrimaryGeneratedColumn, Column, ManyToOne, JoinColumn } from 'typeorm';
import { EntityHelper } from 'src/utils/entity-helper';
import { ApiProperty } from '@nestjs/swagger';
import { User } from '../../users/entities/user.entity';
import { Movie } from '../../movies/entities/movie.entity';

@Entity()
export class Tag extends EntityHelper {
  @PrimaryGeneratedColumn()
  id: number;

  @ManyToOne(() => User)
  @JoinColumn({ name: 'userId' })
  user: User;

  @ApiProperty({ example: 1 }) 
  @Column({ type: 'int' })
  movieId: number;

  @ManyToOne(() => Movie) 
  @JoinColumn({ name: 'movieId' })
  movie: Movie;

  @ApiProperty({ example: 'Inspirational' })
  @Column()
  tag: string;

  @ApiProperty({ example: 1616161616161 })
  @Column({ type: 'bigint' })
  timestamp: number;
}