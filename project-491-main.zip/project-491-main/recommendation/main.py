import numpy as np
import pandas as pd
import re

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity


header = ['user_id', 'item_id', 'rating', 'timestamp']
dataCsv = 'C:/Users/bckal/Desktop/Project 491/dataset/ratings.csv'
df_rating = pd.read_csv(dataCsv, sep=',', names =header, skiprows=1)


header = ['movie_id', 'title', 'genre']
dataCsv = 'C:/Users/bckal/Desktop/Project 491/dataset/movies.csv'
df_movies = pd.read_csv(dataCsv, sep=',', names =header, skiprows=1)


n_users = df_rating.user_id.unique().shape[0]
n_items = df_rating.item_id.unique().shape[0]
print('Number of users = ' + str(n_users) + ' | number of movies = ' + str(n_items))
df_rating.head()

def split_data(data, num_users, num_items, test_ratio):
    mask = [True if x == 1 else False for x in np.random.uniform(0, 1, (len(data))) < 1 - test_ratio]
    neg_mask = [not x for x in mask]
    train_data, test_data = data[mask], data[neg_mask]
    return train_data, test_data


train, test = split_data(df_rating, n_users, n_items, 0.20)

train.head()
test.head()


df_train = df_rating
for i in range(test.shape[0]):
    df_train.loc[(df_train.user_id == test.iloc[[i]].user_id.values[0]) & (
                df_train.item_id == test.iloc[[i]].item_id.values[0]), 'rating'] = 0

df_train.head()


df_test = df_rating
for col in df_test.rating:
    df_test['rating'].values[:] = 0



for i in range(test.shape[0]):
    df_test.loc[(df_test.user_id == test.iloc[[i]].user_id.values[0]) & (
                df_test.item_id == test.iloc[[i]].item_id.values[0]), 'rating'] = test.iloc[[i]].rating.values[0]

df_test.head()

def matrix_factorization(R, P, Q, K, steps=100, alpha=0.002, beta=0.001):
    Q = Q.T
    print(Q)
    for step in range(steps):
        for i in range(len(R)):
            for j in range(len(R[i])):
                if R[i][j] > 0:
                    eij = R[i][j] - np.dot(P[i,:],Q[:,j])
                    for k in range(K):
                        P[i][k] = P[i][k] + alpha * (2 * eij * Q[k][j] - beta * P[i][k])
                        Q[k][j] = Q[k][j] + alpha * (2 * eij * P[i][k] - beta * Q[k][j])
        eR = np.dot(P,Q)
        e = 0
        for i in range(len(R)):
            for j in range(len(R[i])):
                if R[i][j] > 0:
                    e = e + pow(R[i][j] - np.dot(P[i,:],Q[:,j]), 2)
                    for k in range(K):
                        e = e + (beta/2) * ( pow(P[i][k],2) + pow(Q[k][j],2))

        if e < 0.001:
            break

    return P, Q.T

mf_train = df_train.pivot_table(index='user_id', columns='item_id', values='rating', aggfunc='first')
mf_train = mf_train.fillna(0)
mf_train


mf_train = mf_train.to_numpy()
N = len(mf_train)
M = len(mf_train[0])
K = 8
P = np.random.rand(N,K)
Q = np.random.rand(M,K)
user_latent_features, item_latent_features = matrix_factorization(mf_train, P, Q, K)


print("The original matrix")
mf_train

train_pred = np.dot(user_latent_features, item_latent_features.T)
print("The approximation matrix by MF")
train_pred


pred = train_pred
testset = mf_train
total = 0
jum = 0
for i in range(len(testset)):
    for j in range(len(testset[i])):
        if testset[i][j] != 0:
            total += (pred[i][j] - testset[i][j])**2
            jum += 1

mse = total / jum
print('MSE Training = ', mse)
rmse = mse**0.5
print('RMSE Training = ', rmse)


mf_test = df_test.pivot_table(index='user_id', columns='item_id', values='rating', aggfunc='first')
mf_test = mf_test.fillna(0)
mf_test


mf_test = mf_test.to_numpy()

N = len(mf_test)
M = len(mf_test[0])

K = 8

P = np.random.rand(N,K)
Q = np.random.rand(M,K)

user_latent_features_test, item_latent_features_test = matrix_factorization(mf_test, P, Q, K)

print("The original matrix")
mf_test

test_pred = np.dot(user_latent_features_test, item_latent_features_test.T)
print("The approximation matrix by MF")
test_pred

pred = test_pred
testset = mf_test
total = 0
jum = 0
for i in range(len(testset)):
    for j in range(len(testset[i])):
        if testset[i][j] != 0:
            total += (pred[i][j] - testset[i][j])**2
            jum += 1

mse = total / jum
print('MSE = ', mse)
rmse = mse**0.5
print('RMSE = ', rmse)


movie_rec = []
for i in range(len(test_pred)):
  movie_rec.append([np.argsort(-1*test_pred[i])[:10]])

movierec = df_train.pivot_table(index='user_id', columns='item_id', values='rating')
movierec = movierec.fillna(0)

df_movierec = pd.DataFrame(columns=['user', 'movie_recommendation'])
for i in range(len(movie_rec)):
    rec = []
    for j in range(len(movie_rec[i])):
        rec.append(movierec.columns[movie_rec[i][j]])
    movie = []
    for k in range(len(rec[0])):
        movie.append(df_movies.loc[df_movies.movie_id == rec[0][k]].title.values[0])
    df_movierec.loc[i, 'user'] = i
    df_movierec.loc[i, 'movie_recommendation'] = movie


suggested_movie=df_movierec.loc[1].movie_recommendation
print(suggested_movie)


'''CONTENT BASED'''

header = ['movie_id', 'title', 'genre']
dataCsv = 'C:/Users/bckal/Desktop/Project 491/dataset/movies.csv'
df_movies = pd.read_csv(dataCsv, sep=',', names =header, skiprows=1)

df_movies.head()

df_movies.shape

n_title = df_movies.title.unique().shape[0]
print('Number of movies = ', n_title)


'''Pre-processing dataset'''

df_movies['related'] = df_movies['genre'].map(lambda x: x.lower().split('|'))
df_movies.head()


for i in range(df_movies.shape[0]):
  year = re.search(r'(\d4)', df_movies['title'][i])
  if year:
    year = re.sub(r'([()])','', year.group(0))
    df_movies['title'][i] = re.sub(r'(\d4)', '', df_movies['title'][i])
    df_movies['related'][i].append(year+'s')
  df_movies['related'][i] = ','.join(df_movies['related'][i])
print(df_movies.head())

df_movies['titles'] = df_movies['title'].map(lambda x: x.lower().split(' '))
df_movies['titles'] = df_movies['titles'].map(lambda x: ','.join(set(x)))

df_movies['related'] = df_movies['related'] + df_movies['titles']
df_movies.drop(['titles', 'genre'], axis = 1)



header = ['user_id', 'movie_idt', 'tags', 'timestamp']
dataCsv = 'C:/Users/bckal/Desktop/Project 491/dataset/tags.csv'
df_tags = pd.read_csv(dataCsv, sep=',', names =header, skiprows=1)

df_tags = df_tags.groupby(['movie_idt']).agg(lambda x: ','.join(set(x.astype(str)))).reset_index()
df_tags


df_tags['tags'] = df_tags['tags'].map(lambda x: x.lower().split(' '))
df_tags['tags'] = df_tags['tags'].map(lambda x: ','.join(set(x)))
df_tags.head()

df_cbf = pd.concat([df_tags, df_movies], axis=1, sort=False)
df_cbff = df_cbf
df_cbf = df_cbf.replace(np.nan, '', regex=True)
df_cbf['related'] = df_cbf['related'] +','+ df_cbf['tags']
df_cbf

tf = TfidfVectorizer(analyzer='word')
tfidf_matrix = tf.fit_transform(df_cbf['related'])

cos_sim_cbf = cosine_similarity(tfidf_matrix, tfidf_matrix)
cos_sim_cbf


def recommendations(title, cosine_sim=cos_sim_cbf):
    
    recommended_movies = []
   
   
    idx = indices[indices == title].index[0]


    score_series = pd.Series(cosine_sim[idx]).sort_values(ascending=False)


    top_rec = list(score_series.iloc[1:].index)


    for i in top_rec:
        recommended_movies.append(list(df_cbf.index)[i])

    return recommended_movies


df_cbf.set_index('title', inplace=True)
df_cbf.head()

indices = pd.Series(df_cbf.index)
indices

# CBF ile önerileri al
def content_based_recommendations(cosine_sim, n=20):
    recommended_movies = []

    # Rastgele bir film seçmek yerine, tüm filmler için öneri yap
    for movie_title in df_cbf.index:
        score_series = pd.Series(cosine_sim[df_cbf.index == movie_title][0]).sort_values(ascending=False)

        top_rec = list(score_series.iloc[1:].index)

        for i in top_rec:
            recommended_movies.append(list(df_cbf.index)[i])

        if len(recommended_movies) >= n:
            break

    return recommended_movies[:n]

# CBF ile genel önerileri al
sim_movies_general = content_based_recommendations(cos_sim_cbf, n=20)

# Collaborative Filtering ile önerileri al
def collaborative_recommendations(user_id, n=20):
    movrec_u = []
    train_pred_c = train_pred.reshape(9724, 610)

    count = 0
    for mov_id in movierec.columns:
        col_rate = np.where(movierec.columns == mov_id)[0][0]
        rate_user_u = train_pred_c[col_rate][user_id]

        if rate_user_u > 2.5:
            count += 1
            movrec_u.append(mov_id)

        if count >= 20:
            break

    mvr = [df_movies.loc[df_movies.movie_id == mov_id].title.values[0] for mov_id in movrec_u]
    return mvr

# Hybrid önerileri oluştur
def hybrid_recommendations(user_id, cf_weight=0.5, n=20):
    # Collaborative Filtering önerileri
    cf_rec = collaborative_recommendations(user_id, n)

    # Content-Based Filtering önerileri
    cb_rec = content_based_recommendations(cos_sim_cbf, n)

    # Weighted Hybrid öneri
    hybrid_rec = list(set(cf_rec) | set(cb_rec))  # Birleştirme işlemi
    hybrid_rec = hybrid_rec[:n]  # İstenen sayıya kırp

    return hybrid_rec

# Kullanıcı için hybrid önerileri al
user_id = 1  # Kullanıcı ID'si örneğin
hybrid_rec = hybrid_recommendations(user_id, cf_weight=0.5, n=20)

# Sonuçları yazdır
print(hybrid_rec)


