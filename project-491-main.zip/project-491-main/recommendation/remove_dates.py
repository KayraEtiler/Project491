import pandas as pd
import re

# CSV dosyasını oku
df = pd.read_csv('C:/Users/bckal/Desktop/Project 491/dataset/movies.csv')

# 'title' sütunundaki tarihleri sil
df['title'] = df['title'].apply(lambda x: re.sub(r'\s\(\d{4}\)$', '', x) if pd.notna(x) else x)

# Temizlenmiş veriyi başka bir CSV dosyasına kaydet
df.to_csv('C:/Users/bckal/Desktop/Project 491/dataset/cleaned_file.csv', index=False)
