import pandas as pd

# İlk CSV dosyasını oku
df1 = pd.read_csv('C:/Users/bckal/Desktop/Project 491/dataset/ratings_new_edited.csv')

# İkinci CSV dosyasını oku
df2 = pd.read_csv('C:/Users/bckal/Desktop/Project 491/dataset/tags_new_edited.csv')

timestamps_to_paste = df1['timestamp'].values

df2['timestamp'] = timestamps_to_paste


df2.to_csv('C:/Users/bckal/Desktop/Project 491/dataset/tags_new_edited.csv', index=False)