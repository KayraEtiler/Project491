import pandas as pd

# CSV dosyasını oku
file_path = 'C:/Users/bckal/Desktop/Project 491/dataset/movies_new.csv'  # CSV dosyanızın gerçek yolunu belirtin
df = pd.read_csv(file_path)

# Veriyi 'userId' ve 'movieId' sütunlarına göre sırala
df_sorted = df.sort_values(by=['movieId'])

# Sıralanmış veriyi yazdır
output_file_path = 'C:/Users/bckal/Desktop/Project 491/dataset/movies_new.csv'  # Kaydedilecek dosyanın yolunu belirtin
df_sorted.to_csv(output_file_path, index=False, sep=',')
